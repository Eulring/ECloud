import json
fname = 'train_0_1.json'
with open(fname, 'r') as of:
    data = json.load(of)

import ipdb
ipdb.set_trace()